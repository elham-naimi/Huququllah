package com.example.dellxps.huquq;

/**
 * Created by dellxps on 18/4/16.
 */
public class GoldPrice {

    /*POST /freewebservices/GetGoldPrice.asmx HTTP/1.1
Host: www.freewebservicesx.com
Content-Type: application/soap+xml; charset=utf-8
Content-Length: length

<?xml version="1.0" encoding="utf-8"?>
<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
  <soap12:Body>
    <GetCurrentGoldPrice xmlns="http://freewebservicesx.com/">
      <UserName>string</UserName>
      <Password>string</Password>
    </GetCurrentGoldPrice>
  </soap12:Body>
</soap12:Envelope>
HTTP/1.1 200 OK
Content-Type: application/soap+xml; charset=utf-8
Content-Length: length

<?xml version="1.0" encoding="utf-8"?>
<soap12:Envelope xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema" xmlns:soap12="http://www.w3.org/2003/05/soap-envelope">
  <soap12:Body>
    <GetCurrentGoldPriceResponse xmlns="http://freewebservicesx.com/">
      <GetCurrentGoldPriceResult>
        <string>string</string>
        <string>string</string>
      </GetCurrentGoldPriceResult>
    </GetCurrentGoldPriceResponse>
  </soap12:Body>
</soap12:Envelope>*/


    public String getGoldPrice() {
        return goldPrice;
    }

    public void sendRequest(){

    }

    String goldPrice;


}
