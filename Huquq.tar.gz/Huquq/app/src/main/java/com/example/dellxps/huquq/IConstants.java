package com.example.dellxps.huquq;

/**
 * Created by dellxps on 28/4/16.
 */
interface IConstants {

    // Units expressend in terms of mithqals

      double oneMithqalInGramUnit = 3.642;
      double oneMithqalInOunceUnit = 0.1285;
      double oneMithqalInTroyOunceUnit = 0.117093;
      double ninteenMithqalInTroyOunceUnit = oneMithqalInTroyOunceUnit*19;
      int unit_troyOunce = 0;
      int unit_gram = 1;
      int unit_ounce = 3;
 }
