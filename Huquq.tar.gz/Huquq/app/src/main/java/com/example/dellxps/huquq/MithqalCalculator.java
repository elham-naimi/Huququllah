package com.example.dellxps.huquq;

import android.util.Log;

class MithqalCalculator {

    private double xau;
    private double troyOunce;
    private double ounce;
    private double pound;
    private double gram;
    private static String TAG = MithqalCalculator.class.getSimpleName();


    MithqalCalculator(double xau) {
        this.xau = xau;
        initialiseAllUnits();

    }

    public double getTroyOunce() {
        return troyOunce;
    }

    public double getXau() {
        return xau;
    }

    public double getOunce() {
        return ounce;
    }

    public double getPound() {
        return pound;
    }

    public double getGram() {
        return gram;
    }


    private void initialiseAllUnits() {

        troyOunce = 1 / xau;
        ounce = troyOunce / 1.09714;   // 1 troy ounce = 1.09714 oz
        gram = troyOunce / 31.1035;    // 1 troy ounce = 31.1035 grams
        pound = troyOunce / 0.0685714; // 1 troy ounce = 0.0685714 pounds

        Log.d(TAG, "MithqalCalculator::" + xau);
        Log.d(TAG, "Troy goldValuePerOunce ::" + troyOunce);
        Log.d(TAG, "Ounce ::" + ounce);
        Log.d(TAG, "Pound ::" + pound);
        Log.d(TAG, "Gram ::" + gram);
    }

    protected String getGoldPrice(int count, int unit) {
        double results = 0;
        switch (unit) {
            case 0:
            case 1:
                results = (IConstants.oneMithqalInTroyOunceUnit * count * troyOunce) ;
                break;
           /* case IConstants.unit_gram:// Gold value of count number of grams
                Log.d(TAG, count + " mithqal = " + (IConstants.oneMithqalInGramUnit * count * gram) + " grams");
                break;*/

        }
        return Math.round(results*1000.00)/1000.00 + "";
    }


}