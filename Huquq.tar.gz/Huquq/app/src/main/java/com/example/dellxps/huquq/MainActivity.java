package com.example.dellxps.huquq;

import android.app.Activity;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;


public class MainActivity extends Activity {


    private static final String TAG = MainActivity.class.getSimpleName();
    MithqalCalculator mMithqalCalc;
    double ninteenMithqalValue;
    String units[]={"Troy Ounce","Gram"};
    String unitsPrice[]={"USD","INR","EUR"};
    EditText editTxt19Mithqals;
    TextView textView19Mithqals;
    TextView textView_weight_results, textView_currency_results;
    TextView textView_weight_title, textView_currency_title;
    Spinner spWeight;
    Spinner spCurrency;
    Button bttnCalculate;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sendHttpRequest();
        spWeight = (Spinner) findViewById(R.id.sp1);
        editTxt19Mithqals =(EditText)findViewById(R.id.ninteen_mithqals);
        editTxt19Mithqals.setText("19");
        editTxt19Mithqals.setSelection(editTxt19Mithqals.getText().length());
        textView19Mithqals =(TextView)findViewById(R.id.txtMithqal1);
        spWeight = (Spinner) findViewById(R.id.sp2);
        spCurrency = (Spinner) findViewById(R.id.sp1);
        textView_currency_title = (TextView) findViewById(R.id.title_currency);
        textView_weight_title = (TextView) findViewById(R.id.title_weight);
        textView_weight_results = (TextView)findViewById(R.id.textView_weight_results);
        textView_currency_results = (TextView) findViewById(R.id.textview_currency_results);
        ArrayAdapter<String> adapterUnits= new ArrayAdapter<String>(this,android.
                R.layout.simple_spinner_dropdown_item ,units);
        spWeight.setAdapter(adapterUnits);
        ArrayAdapter<String> adapterUnitsPrice= new ArrayAdapter<String>(this,android.
                R.layout.simple_spinner_dropdown_item ,unitsPrice);
        spCurrency.setAdapter(adapterUnitsPrice);
        textView_weight_results.setText(
                getUnitsInMithqals(Integer.parseInt(editTxt19Mithqals.getText().toString()),0));

        Typeface roboto_black = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Black.ttf");
        Typeface roboto_medium = Typeface.createFromAsset(getAssets(), "fonts/Roboto-Medium.ttf");
        textView_currency_title.setTypeface(roboto_medium);
        textView_weight_title.setTypeface(roboto_medium);

        editTxt19Mithqals.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                if(!isEmpty(editTxt19Mithqals)) {

                    textView_currency_results.setText(
                            mMithqalCalc.getGoldPrice(Integer.parseInt(editTxt19Mithqals.getText().toString()), spCurrency.getSelectedItemPosition()));
                    textView_weight_results.setText(
                            getUnitsInMithqals(Integer.parseInt(editTxt19Mithqals.getText().toString()), spWeight.getSelectedItemPosition()));
                }
            }
        });
    }

    private void sendHttpRequest() {
        String apikey = "75357df719faa03763beac4af5205a62";
        String url = "http://www.apilayer.net/api/live?access_key="+apikey+"& currencies = MithqalCalculator";
        OkHttpClient okHttpClient = new OkHttpClient();
        Request request = new Request.Builder()
                .url(url)
                .build();
        Call call = okHttpClient.newCall(request);
        call.enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {

            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                if(response.isSuccessful()){
                    String jsonData = response.body().string();
                    Log.d(TAG,"Response :"+jsonData);
                    mMithqalCalc = parse(jsonData);
                    Log.d(TAG, "MithqalCalculator" + mMithqalCalc.getXau());
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {

                            textView_currency_results.setText(
                                    mMithqalCalc.getGoldPrice(Integer.parseInt(editTxt19Mithqals.getText().toString()),spCurrency.getSelectedItemPosition()));

                            spWeight.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                    textView_weight_results.setText(
                                            getUnitsInMithqals
                                                    (Integer.parseInt(editTxt19Mithqals.getText().toString()), spWeight.getSelectedItemPosition()));

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                            spCurrency.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                                @Override
                                public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                                    textView_currency_results.setText(
                                            mMithqalCalc.getGoldPrice(Integer.parseInt(editTxt19Mithqals.getText().toString()),spCurrency.getSelectedItemPosition()));

                                }

                                @Override
                                public void onNothingSelected(AdapterView<?> parent) {

                                }
                            });
                        }
                    });
                }else{
                    alertUserAboutError();
                }

            }
        });
    }


    private MithqalCalculator parse(String jsonData) {
        double xau = 0;
        // the following line converts the JSON Response to an equivalent Java Object
        try {
            JSONObject exchangeRates = new JSONObject(jsonData);
             xau = exchangeRates.getJSONObject("quotes").getDouble("USDXAU");

        } catch (JSONException e) {
            e.printStackTrace();
        }
        return new MithqalCalculator(xau);

    }

    private void alertUserAboutError() {

    }

    protected String getUnitsInMithqals(int count, int unit) {
        double results = 0;
        switch (unit) {
            case IConstants.unit_troyOunce: // troy goldValuePerOunce
                results = (IConstants.oneMithqalInTroyOunceUnit * count);
                break;
            case IConstants.unit_gram:// goldValuePerGram
                results = (IConstants.oneMithqalInGramUnit * count);
                break;

        }
        //   return results+"";
        return Math.round(results*10000.00)/10000.00 + "";

    }

    private boolean isEmpty(EditText etText) {
        return etText.getText().toString().trim().length() == 0;
    }

}
